from django.apps import AppConfig


class RelecloudConfig(AppConfig):
    name = "relecloud"
