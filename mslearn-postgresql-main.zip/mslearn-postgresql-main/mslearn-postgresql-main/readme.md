# PostgreSQL Exercises

This repository contains the instructions and files to support PostgreSQL exercises in [Microsoft Learn](https://learn.microsoft.com) modules.
