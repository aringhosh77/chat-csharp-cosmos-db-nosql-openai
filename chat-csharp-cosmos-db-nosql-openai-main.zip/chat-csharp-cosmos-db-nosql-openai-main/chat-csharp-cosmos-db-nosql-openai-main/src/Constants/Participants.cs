namespace Cosmos.Chat.GPT.Constants;

public enum Participants
{
    User = 0,
    Assistant
}