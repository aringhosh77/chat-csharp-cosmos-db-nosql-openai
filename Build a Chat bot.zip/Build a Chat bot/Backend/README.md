# cosmos-db-dev-guide-backend-app-python
