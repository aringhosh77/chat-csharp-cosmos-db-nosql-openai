# cosmos-db-openai-python-dev-guide-labs
Azure Cosmos DB + Azure OpenAI Python developer guide companion labs
