namespace Cosmos.Chat.GPT.Constants;

public static class Interface
{
    public static readonly string EMPTY_SESSION = "empty-session-404";
}